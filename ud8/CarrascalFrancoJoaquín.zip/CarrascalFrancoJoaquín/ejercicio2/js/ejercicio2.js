let startMsg = "¿¿¿Que muestre un qué???"; 
alert(startMsg);