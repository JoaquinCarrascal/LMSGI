let numero1 = 5;
let numero2 = 8;

if(numero1 < numero2){
    alert("número1 no es mayor que número2");
}

if(numero2 > 0){
    alert("número2 es positivo");
}

if(numero1 != 0){
    alert("numero1 es negativo o distinto de 0");
}

if((numero1++) < numero2 ){
    alert("incrementar número 1 en una unidad no lo hace mayor que número 2");
}