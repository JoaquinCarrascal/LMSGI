let lista = ["Enero","Febrero","Marzo","Abril","Mayo","Junio",
             "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
             
let text = lista.join(' ');

//for (let x of lista) {
//    text += x + " ";
//}

alert(text);